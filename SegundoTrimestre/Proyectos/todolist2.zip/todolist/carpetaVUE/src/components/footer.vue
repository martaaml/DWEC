<script setup>

</script>

<template>
<footer>
   <p>Marta Marín Lorente</p>
   <p>Copyright © 2025 Todos los derechos reservados</p>
</footer>
</template>

<style scoped>

</style>