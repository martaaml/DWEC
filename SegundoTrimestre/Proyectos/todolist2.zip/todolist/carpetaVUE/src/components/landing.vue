<script setup>


</script>

<template>
    <section>
        Bienvenido a la aplicación de gestión de tareas, es un placer ayudarte a gestionar tus tareas.
        Para poder utilizar la aplicación debes iniciar sesión, para ello puede ser a través de Google o con tu correo electrónico.
        <br>
        <br>
        Para crear una nueva tarea, haz click en el botón "Nueva tarea" en la parte superior derecha de la pantalla.
        <br>
        <br>
        Las tareas se pueden ordenar por prioridad, por fecha y por completado.
        <br>
        <br>
        Se pueden controlar las horas de las tareas
        <br>
        <br>
        Las tareas tendrán la opcion de ser borradas o modificadas.
        <br>
        <br>
        Tus tareas se guardarán en la base de datos de Firebase.
        <br>
        <br>
        Aqui tienes una vista previa de la aplicación y su usabilidad:
        <br>
        <br>
        <video src="../assets/video.mp4" muted autoplay alt="Vista previa de la aplicación"></video>
        Puedes ver comentarios de la gente aqui:
    </section>

</template>